  <div class="clear"></div>

</div><!--//main_container-->

<div id="footer">
 Copyright 2011. All Rights Reserved. Design & Developed by <a href="http://www.dessign.net">Dessign.net</a>
</div><!--//footer-->

<?php wp_footer(); ?>
<!--%@##--><div style="margin: 1em 0 3em 0; text-align: center;">Find more free <a href="http://www.freewebtemplates.com/wordpress-themes/">WordPress themes</a> at <a href="http://www.freewebtemplates.com/">Free Website Templates</a>.</div><!--##@%-->
</body>
</html>